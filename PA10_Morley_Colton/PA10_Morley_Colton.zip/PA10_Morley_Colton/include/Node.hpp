#ifndef NODE_H_
#define NODE_H_

template <typename T>
class Node;

template <typename T>
class NodeStack;

template <typename T>
class Node{
    friend class NodeStack<T>;

    public:
        Node()
        {
            m_next = nullptr;
            m_data = T();
        }
        Node(const T & data, Node * next = nullptr)
        {
            m_data = data;
            m_next = next;
        }
        T & data()
        {
            return m_data;
        }
        const T & data() const
        {
            return m_data;
        }
    
    private:
        Node * m_next;
        T m_data;
};




#endif

