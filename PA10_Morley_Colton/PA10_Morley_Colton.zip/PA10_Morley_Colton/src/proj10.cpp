#include <iostream>
#include "Node.hpp"
#include "NodeStack.hpp"
#include "ArrayStack.hpp"

using std::cout;
using std::endl;

int main()
{
    cout << endl << endl
         << "////////////////////////////////////" << endl
         << "///// ArrayStack and Stack ///////" << endl
         << "/////      Test Driver       ///////" << endl
         << "////////////////////////////////////" << endl << endl << endl; 

    cout << "////////////////////////////////////" << endl
         << "//// Beginning ArrayQueue Tests /////" << endl
         << "////////////////////////////////////" << endl << endl << endl;     

    cout << "Testing Default, Parameterized and Copy ctors and also << overload" << endl << endl;
    
        ArrayStack<int> a1;
        ArrayStack<int> a2(3, 42);
        ArrayStack<int> a3(a2);

        cout << a1 << endl << a2 << endl << a3 << endl;

    cout << "Testing Push" << endl << endl;

        a2.push(26);
        cout << a2 << endl;

    cout << endl << "Testing Pop" << endl << endl;

        a2.pop();
        cout << a2 << endl;

    cout << "Testing push on a full array" << endl;

        ArrayStack<int, 3> a4(3, 50);
        a4.push(19);
        cout << a4 << endl;
    
    cout << endl << "Testing pop on an empty array" << endl;
        a4.clear();
        a4.pop();

    cout << endl << "Testing Assignment Operator" << endl;
    cout << "  (Both outputs should be identical)" << endl << endl;

        ArrayStack<int> a5;
        a5 = a2;
        cout << a5 << endl << a2 << endl;

    cout << "////////////////////////////////////" << endl
         << "//// Beginning NodeStack Tests /////" << endl
         << "////////////////////////////////////" << endl << endl << endl;

cout << "Testing Default, Parameterized and Copy ctors and also << overload" << endl << endl;  

    NodeStack<int> n1;
    NodeStack<int> n2(3, 42);
    NodeStack<int> n3(n2);
    cout << endl << n1 << endl; 
        cout << n2 << endl; 
        cout << n3 << endl << endl;

cout << "Testing Push" << endl << endl;

        n2.push(15);
        cout << n2 << endl;

cout << endl << "Testing Pop" << endl << endl;

        n2.pop();
        cout << n2 << endl;

cout << endl << "Testing pop on empty NodeStack" << endl;
        
        n1.pop();

cout << endl << "Testing Assignment Operator" << endl;
    cout << "  (Both outputs should be identical)" << endl << endl;
       
        NodeStack<int> n4;
        n4 = n2;
        cout << n2 << endl << n4 << endl << endl;

    cout << "----------------------------------------------------------" << endl << endl;
    return 0;
}