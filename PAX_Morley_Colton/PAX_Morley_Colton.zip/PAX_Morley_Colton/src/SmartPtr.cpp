//Colton Morley lab 1103
//Implementation for SmartPtr class

#include <iostream>
#include "DataType.h"
#include "SmartPtr.h"

using namespace std;
    
    //Default Constructor
    SmartPtr::SmartPtr( )
    {
        //Requests allocation of DataType and size_t
        m_ptr = new (nothrow) DataType;
        m_refcount = new (nothrow) size_t;
        (*m_refcount) = 1;
        //Checks to ensure that allocation was succesfuls
        if(m_ptr == nullptr || m_refcount == nullptr){
            cout << "Default Constructor Dynamic Allocation failed"<< endl;
            return;
        }
        //Prints debug output
        cout << "SmartPtr Default Constructor for new allocation, RefCount = " <<
                *m_refcount << endl;

    }
    //Parameterized ctor
    SmartPtr::SmartPtr( DataType * data )
    {
        //sets ptr to point to data and allocates new memory for refcount
        m_ptr = data;
        m_refcount = new (nothrow) size_t;
        //checks if data/m_ptr is pointing to anything and sets refconut accordingly
        if(data == nullptr)
        {
            (*m_refcount) = 0;
        }
        else 
        {
            (*m_refcount) = 1;
        }
        //Debug Output
        cout << "SmartPtr Parameterized Constrctor from data pointer, RefCount = " <<
                *m_refcount << endl;
    }
    //Copy ctor
    SmartPtr::SmartPtr( const SmartPtr & other )
    {
        //Sets ptr and refcount to the other smartptr
        m_ptr = other.m_ptr;
        m_refcount = other.m_refcount;
        //Checks if other smart ptr points to anything and sets refcount accordingly
        if(m_ptr == nullptr)
        {
            (*m_refcount) = 0;
        }
        else
        {
            (*m_refcount)++;
        }
        //Prints debug output
         cout << "SmartPtr Copy Constrctor, RefCount = " <<
                *m_refcount << endl;
    }
    
    SmartPtr::~SmartPtr( )
    {
        //Decrements smart_ptr only if it does not already = 0
        if(*m_refcount > 0){
        (*m_refcount)--;
        }
        //Debug output
        cout << "SmartPtr Destructor, RefCount = " <<
            *m_refcount << endl;
        /*
        If ptr is not already null and there is nothing else point to this memory
        Deletes memory and prints an extra debug output to help make sure dynamic memory
        is being deallocated when it should be
        */
        if(m_ptr != nullptr && *m_refcount == 0)
        {
            delete m_ptr;
            delete m_refcount;
            cout << "Memory Deallocated" << endl;
        } 
    }
    //Assignment Operator
    SmartPtr & SmartPtr::operator=( const SmartPtr & rhs )
    {
        //Decrements the left hand side refcount as it will no longer be pointing to
        //the same address
        (*m_refcount)--;
        /*
        If that was the last thing pointing to that addresss it will deallocate the memory
        and print a debug output to ensure memory is being deallocaed at the right
        times
        */
        if(*m_refcount == 0)
        {
            delete m_ptr;
            delete m_refcount;
            m_ptr = nullptr;
            m_refcount = nullptr;
            cout << "Memory Deallocated" << endl;
        }
        //Sets LHS values to RHS values
        m_ptr = rhs.m_ptr;
        m_refcount = rhs.m_refcount;
        //CHecks if RHS is pointing to anything and adjusts refcount accordingly
        if(m_ptr == nullptr)
        {
            (*m_refcount) = 0;
        }
        else
        {
            (*m_refcount)++;
        }
        //Prints debug output
        cout << "SmartPtr Copy Assignment, RefCount = " << 
                *m_refcount << endl;
        
        return *this;
    }

    //Returns *m_ptr for dereferencing
    DataType & SmartPtr::operator*( )
    {
        return (*m_ptr);
    }
    //Returns m_ptr so it can be used the same as regular operator ->
    DataType * SmartPtr::operator->( )
    {
        return m_ptr;
    }